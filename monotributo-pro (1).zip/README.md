
# Monotributo Pro 🚀

Sistema de gestión contable diseñado para contadores independientes. Permite el seguimiento de facturación, límites de categorías y exportación de reportes para clientes.

## 🛠️ Estructura del Proyecto

- `index.html`: Punto de entrada con Tailwind CSS y React via ESM.
- `App.tsx`: Enrutamiento y lógica principal de la sesión.
- `/pages`: Vistas de Dashboard, Login, Clientes y Reporte Público.
- `constants.tsx`: Valores actualizados de escalas ARCA 2026.

## 🚀 Despliegue

Este proyecto está optimizado para **Netlify**. Solo arrastra la carpeta raíz al panel de Netlify Drop o conecta este repositorio de GitHub.

## 📄 Licencia
Privado - Uso Profesional.
